Developed by Eddie Lee (eddie@illogictree.com)
Twitter: @eddietree

Homepage: illogictree.com
Official Page: http://illogictree.com/games/psychotropic/

Audio by Jack Menhorn (jackmenhorn.com)


All Rights Reserved 2012